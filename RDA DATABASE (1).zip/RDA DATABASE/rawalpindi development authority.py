import tkinter as tk
from tkinter import messagebox
import mysql.connector
from datetime import datetime

# Connect to MySQL database
try:
    con = mysql.connector.connect(
        host="localhost",
        user="root",
        password="PHW#84#jeor",
        database="rda"
    )
    cur = con.cursor(buffered=True)
except mysql.connector.Error as err:
    print("An error occurred while connecting to the database:", err)
    exit()

# Function to insert employee data
def insert_employee():
    first_name = first_name_entry.get()
    last_name = last_name_entry.get()
    department = department_entry.get()
    position = position_entry.get()
    hire_date = hire_date_entry.get()

    if not first_name or not last_name or not department or not position or not hire_date:
        messagebox.showerror("Error", "Please fill in all fields.")
        return

    try:
        # Ensure the date is in correct format
        hire_date_formatted = datetime.strptime(hire_date, '%Y-%m-%d').date()

        cur.execute("""
            INSERT INTO Employee (FirstName, LastName, Department, Position, HireDate)
            VALUES (%s, %s, %s, %s, %s)
        """, (first_name, last_name, department, position, hire_date_formatted))
        con.commit()
        messagebox.showinfo("Success", "Employee data inserted successfully.")
    except ValueError:
        messagebox.showerror("Error", "Incorrect date format. Please use YYYY-MM-DD.")
    except mysql.connector.Error as err:
        messagebox.showerror("Error", f"An error occurred while inserting data: {err}")

# Function to mark attendance
def mark_attendance():
    employee_id = attendance_employee_id_entry.get()
    attendance_date = attendance_date_entry.get()
    status = attendance_status_entry.get()

    if not employee_id or not attendance_date or not status:
        messagebox.showerror("Error", "Please fill in all fields.")
        return

    try:
        # Ensure the date is in correct format
        attendance_date_formatted = datetime.strptime(attendance_date, '%Y-%m-%d').date()

        cur.execute("CALL MarkAttendance(%s, %s, %s)", (employee_id, attendance_date_formatted, status))
        con.commit()
        messagebox.showinfo("Success", "Attendance marked successfully.")
    except ValueError:
        messagebox.showerror("Error", "Incorrect date format. Please use YYYY-MM-DD.")
    except mysql.connector.Error as err:
        messagebox.showerror("Error", f"An error occurred while marking attendance: {err}")

# Function to retrieve attendance records
def retrieve_attendance():
    employee_id = retrieve_employee_id_entry.get()

    if not employee_id:
        messagebox.showerror("Error", "Please enter the Employee ID.")
        return

    try:
        cur.execute("""
            SELECT e.FirstName, e.LastName, a.AttendanceDate, a.Status
            FROM Employee e
            JOIN Attendance a ON e.EmployeeID = a.EmployeeID
            WHERE e.EmployeeID = %s
        """, (employee_id,))
        records = cur.fetchall()

        result_window = tk.Toplevel(root)
        result_window.title("Attendance Records")
        
        for idx, record in enumerate(records, start=1):
            tk.Label(result_window, text=f"{idx}. {record[0]} {record[1]} - {record[2]} - {record[3]}").pack()

    except mysql.connector.Error as err:
        messagebox.showerror("Error", f"An error occurred while retrieving attendance records: {err}")

# Function to retire an employee
def retire_employee():
    employee_id = retire_employee_id_entry.get()

    if not employee_id:
        messagebox.showerror("Error", "Please enter the Employee ID.")
        return

    try:
        # Delete employee's attendance records
        cur.execute("DELETE FROM Attendance WHERE EmployeeID = %s", (employee_id,))
        con.commit()

        # Delete employee's record
        cur.execute("DELETE FROM Employee WHERE EmployeeID = %s", (employee_id,))
        con.commit()

        messagebox.showinfo("Success", f"Employee with ID {employee_id} has been retired and their data deleted.")
    except mysql.connector.Error as err:
        messagebox.showerror("Error", f"An error occurred while retiring the employee: {err}")

# Create main Tkinter window
root = tk.Tk()
root.title("RDA Attendance Management System")

# Insert Employee Section
tk.Label(root, text="Insert Employee Data", font=("Helvetica", 16)).grid(row=0, column=0, columnspan=2, pady=10)

tk.Label(root, text="First Name:").grid(row=1, column=0, padx=10, pady=5, sticky="e")
first_name_entry = tk.Entry(root)
first_name_entry.grid(row=1, column=1, padx=10, pady=5)

tk.Label(root, text="Last Name:").grid(row=2, column=0, padx=10, pady=5, sticky="e")
last_name_entry = tk.Entry(root)
last_name_entry.grid(row=2, column=1, padx=10, pady=5)

tk.Label(root, text="Department:").grid(row=3, column=0, padx=10, pady=5, sticky="e")
department_entry = tk.Entry(root)
department_entry.grid(row=3, column=1, padx=10, pady=5)

tk.Label(root, text="Position:").grid(row=4, column=0, padx=10, pady=5, sticky="e")
position_entry = tk.Entry(root)
position_entry.grid(row=4, column=1, padx=10, pady=5)

tk.Label(root, text="Hire Date (YYYY-MM-DD):").grid(row=5, column=0, padx=10, pady=5, sticky="e")
hire_date_entry = tk.Entry(root)
hire_date_entry.grid(row=5, column=1, padx=10, pady=5)

insert_employee_button = tk.Button(root, text="Insert Employee", command=insert_employee)
insert_employee_button.grid(row=6, column=0, columnspan=2, pady=10)

# Mark Attendance Section
tk.Label(root, text="Mark Attendance", font=("Helvetica", 16)).grid(row=7, column=0, columnspan=2, pady=10)

tk.Label(root, text="Employee ID:").grid(row=8, column=0, padx=10, pady=5, sticky="e")
attendance_employee_id_entry = tk.Entry(root)
attendance_employee_id_entry.grid(row=8, column=1, padx=10, pady=5)

tk.Label(root, text="Attendance Date (YYYY-MM-DD):").grid(row=9, column=0, padx=10, pady=5, sticky="e")
attendance_date_entry = tk.Entry(root)
attendance_date_entry.grid(row=9, column=1, padx=10, pady=5)

tk.Label(root, text="Status (Present/Absent/Leave):").grid(row=10, column=0, padx=10, pady=5, sticky="e")
attendance_status_entry = tk.Entry(root)
attendance_status_entry.grid(row=10, column=1, padx=10, pady=5)

mark_attendance_button = tk.Button(root, text="Mark Attendance", command=mark_attendance)
mark_attendance_button.grid(row=11, column=0, columnspan=2, pady=10)

# Retrieve Attendance Section
tk.Label(root, text="Retrieve Attendance", font=("Helvetica", 16)).grid(row=12, column=0, columnspan=2, pady=10)

tk.Label(root, text="Employee ID:").grid(row=13, column=0, padx=10, pady=5, sticky="e")
retrieve_employee_id_entry = tk.Entry(root)
retrieve_employee_id_entry.grid(row=13, column=1, padx=10, pady=5)

retrieve_attendance_button = tk.Button(root, text="Retrieve Attendance", command=retrieve_attendance)
retrieve_attendance_button.grid(row=14, column=0, columnspan=2, pady=10)

# Retire Employee Section
tk.Label(root, text="Retire Employee", font=("Helvetica", 16)).grid(row=15, column=0, columnspan=2, pady=10)

tk.Label(root, text="Employee ID:").grid(row=16, column=0, padx=10, pady=5, sticky="e")
retire_employee_id_entry = tk.Entry(root)
retire_employee_id_entry.grid(row=16, column=1, padx=10, pady=5)

retire_employee_button = tk.Button(root, text="Retire Employee", command=retire_employee)
retire_employee_button.grid(row=17, column=0, columnspan=2, pady=10)

# Start the Tkinter event loop
root.mainloop()
