Create database rda;
use rda;




CREATE TABLE Employee (
    EmployeeID INT PRIMARY KEY AUTO_INCREMENT,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Department VARCHAR(50),
    Position VARCHAR(50),
    HireDate DATE
);

-- Create Attendance Table
CREATE TABLE Attendance (
    AttendanceID INT PRIMARY KEY AUTO_INCREMENT,
    EmployeeID INT,
    AttendanceDate DATE,
    Status ENUM('Present', 'Absent', 'Leave') DEFAULT 'Absent',
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);

-- Insert sample data into Employee Table
-- Example entries for dynamic employee data
INSERT INTO Employee (FirstName, LastName, Department, Position, HireDate) VALUES
('John', 'Doe', 'Engineering', 'Engineer', '2020-01-15'),
('Jane', 'Smith', 'HR', 'Manager', '2019-03-22'),
('Alex', 'Johnson', 'Finance', 'Analyst', '2021-06-10'),
('Emily', 'Clark', 'Marketing', 'Specialist', '2023-01-12');

-- Create Procedure to Mark Attendance
DELIMITER //

CREATE PROCEDURE MarkAttendance(IN empID INT, IN attDate DATE, IN attStatus ENUM('Present', 'Absent', 'Leave'))
BEGIN
    INSERT INTO Attendance (EmployeeID, AttendanceDate, Status)
    VALUES (empID, attDate, attStatus)
    ON DUPLICATE KEY UPDATE Status = attStatus;
END //

DELIMITER ;

-- Sample usage of the procedure to mark attendance for some employees
CALL MarkAttendance(1, '2024-07-02', 'Present');
CALL MarkAttendance(2, '2024-07-02', 'Absent');
CALL MarkAttendance(3, '2024-07-02', 'Present');
CALL MarkAttendance(4, '2024-07-02', 'Leave');

-- Query to retrieve all attendance records
SELECT * FROM Attendance;

-- Query to retrieve attendance records for a specific employee
SELECT e.FirstName, e.LastName, a.AttendanceDate, a.Status
FROM Employee e
JOIN Attendance a ON e.EmployeeID = a.EmployeeID
WHERE e.EmployeeID = 1;

-- Query to retrieve attendance records for all employees on a specific date
SELECT e.FirstName, e.LastName, a.AttendanceDate, a.Status
FROM Employee e
JOIN Attendance a ON e.EmployeeID = a.EmployeeID
WHERE a.AttendanceDate = '2024-07-02';

-- Monthly attendance summary for all employees
SELECT e.FirstName, e.LastName, 
       SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) AS DaysPresent,
       SUM(CASE WHEN a.Status = 'Absent' THEN 1 ELSE 0 END) AS DaysAbsent,
       SUM(CASE WHEN a.Status = 'Leave' THEN 1 ELSE 0 END) AS DaysOnLeave
FROM Employee e
LEFT JOIN Attendance a ON e.EmployeeID = a.EmployeeID
WHERE MONTH(a.AttendanceDate) = 7 AND YEAR(a.AttendanceDate) = 2024
GROUP BY e.EmployeeID;

-- Add a new employee
INSERT INTO Employee (FirstName, LastName, Department, Position, HireDate) 
VALUES ('Michael', 'Brown', 'Operations', 'Supervisor', '2022-02-10');

-- Update employee details
UPDATE Employee
SET Department = 'IT', Position = 'Developer'
WHERE EmployeeID = 3;

-- Remove an employee
DELETE FROM Employee
WHERE EmployeeID = 2;

select * from employee;
select * from attendance;

